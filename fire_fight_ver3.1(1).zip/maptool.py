from pico2d import *
import random
import math


class Tile:
    wood1, wood2, wood3, wood4 = None, None, None, None
    water = None
    grass, grass2, grass3 = None, None, None

    def __init__(self):
        self.x, self.y = 0, 0
        self.state = 1000


    def load_img(self):
        if Tile.wood1 == None and self.state == 1020:
            Tile.wood1 = load_image('C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\img\\use_img\\Map\\wood1.png')
        if Tile.wood2 == None and self.state == 1040:
            Tile.wood2 = load_image('C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\img\\use_img\\Map\\wood2.png')
        if Tile.wood3 == None and self.state == 1060:
            Tile.wood3 = load_image('C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\img\\use_img\\Map\\wood3.png')
        if Tile.wood4 == None and self.state == 1080:
            Tile.wood4 = load_image('C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\img\\use_img\\Map\\wood4.png')
        if Tile.water == None and self.state == 1100:
            Tile.water = load_image('C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\img\\use_img\\Map\\bg_water.png')
        if Tile.grass == None and self.state == 1120:
            Tile.grass = load_image('C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\img\\use_img\\Map\\bg_grass.png')
        if Tile.grass2 == None and self.state == 1140:
            Tile.grass2 = load_image('C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\img\\use_img\\Map\\bg_grass2.png')
        if Tile.grass3 == None and self.state == 1160:
            Tile.grass3 = load_image('C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\img\\use_img\\Map\\bg_grass3.png')


    def draw(self):
        if self.state == 1020:
            self.wood1.draw(self.x, self.y)
        elif self.state == 1040:
            self.wood2.draw(self.x, self.y)
        elif self.state == 1060:
            self.wood3.draw(self.x, self.y)
        elif self.state == 1080:
            self.wood4.draw(self.x, self.y)
        elif self.state == 1100:
            self.water.draw(self.x, self.y)
        elif self.state == 1120:
            self.grass.draw(self.x, self.y)
        elif self.state == 1140:
            self.grass2.draw(self.x, self.y)
        elif self.state == 1160:
            self.grass3.draw(self.x, self.y)



def mou_events():
    global level
    global Menu
    global bg
    global x, y
    global file

    events = get_events()
    for event in events:
        if event.type == SDL_MOUSEMOTION:
            mouX, mouY = event.x, Size[1] - event.y
            ##

        if event.type == SDL_QUIT:
            Menu = False
        elif event.type == SDL_KEYDOWN and event.key == SDLK_ESCAPE:
            Menu = False
        elif event.type == SDL_KEYDOWN and event.key == SDLK_LEFT:
            x = x - 20
        elif event.type == SDL_KEYDOWN and event.key == SDLK_RIGHT:
            x = x + 20
        elif event.type == SDL_KEYDOWN and event.key == SDLK_UP:
            y = y + 20
        elif event.type == SDL_KEYDOWN and event.key == SDLK_DOWN:
            y = y - 20

        elif event.type == SDL_KEYDOWN and event.key == SDLK_1:
            level = 1020
        elif event.type == SDL_KEYDOWN and event.key == SDLK_2:
            level = 1040
        elif event.type == SDL_KEYDOWN and event.key == SDLK_3:
            level = 1060
        elif event.type == SDL_KEYDOWN and event.key == SDLK_4:
            level = 1080
        elif event.type == SDL_KEYDOWN and event.key == SDLK_5:
            level = 1100
        elif event.type == SDL_KEYDOWN and event.key == SDLK_6:
            level = 1120
        elif event.type == SDL_KEYDOWN and event.key == SDLK_7:
            level = 1140
        elif event.type == SDL_KEYDOWN and event.key == SDLK_8:
            level = 1160
        elif event.type == SDL_KEYDOWN and event.key == SDLK_9:
            level = 1000
        elif event.type == SDL_KEYDOWN and event.key == SDLK_SPACE:
            bg[(int)(y / 20)][(int)(x / 20)].state = level
            bg[(int)(y / 20)][(int)(x / 20)].load_img()
        elif event.type == SDL_KEYDOWN and event.key == SDLK_r:
            for i in range((int)(Size[1] / 20)):
                for j in range((int)(Size[0] / 20)):
                    data = [bg[i][j].x, bg[i][j].y, bg[i][j].state]
                    file.write('%d, %d, %d\n'% (data[0], data[1], data[2]))
                    Menu = False




Size = [900, 600]
Menu = True
i,j = 0, 0
level = 1000
x,y = 10, 10
file = open("map1(900, 600).txt", "w")

open_canvas(Size[0], Size[1])
bg = [[Tile() for one in range((int)(Size[0]/20))] for two in range((int)(Size[1]/20))]
location = load_image('C:\\Users\\punch\\Desktop\\File\\2D\here\\flod\\Fire_Fight\\img\\square.png')

for i in range((int)(Size[1] / 20)):
    for j in range((int)(Size[0] / 20)):
        bg[i][j].x, bg[i][j].y = j*20+10, i*20+10
        gra = random.randint(0,2)
        if gra == 0:
            bg[i][j].state = 1120
        elif gra == 1:
            bg[i][j].state = 1140
        elif gra == 2:
            bg[i][j].state = 1160
        bg[i][j].load_img()


while Menu:
    mou_events()
    clear_canvas()


    for i in range((int)(Size[1] / 20)):
        for j in range((int)(Size[0] / 20)):
            bg[i][j].draw()
    location.draw(x, y)
    update_canvas()
    delay(0.05)

file.close()
close_canvas()

