import Main_Manager
from Character import character
from globalVari import GV
from State_BackGround import BackGround
from Fire import Fire
from pico2d import *
import State_Main


gv = GV()

chmp = None
image = None
blackScreen = None
fire = None
map = None
item = [0 for i in range(3)]
damage = 30
keyA = False



def load_file(stage):
    f = open("map3(900, 600).txt", 'r')
    for i in range(gv.Height // gv.standardPixel):
        for j in range(gv.Width // gv.standardPixel):
            map[i][j].x = (int)(f.readline())
            map[i][j].y = (int)(f.readline())
            map[i][j].state = (int)(f.readline())
    f.close()



def enter():
    global blackScreen
    global map, chmp, fire

    chmp = character()
    fire =[[Fire()for i in range(gv.Width//gv.standardPixel)] for j in range(gv.Height//gv.standardPixel)]
    map = [[BackGround() for i in range(gv.Width//gv.standardPixel)] for j in range(gv.Height//gv.standardPixel)]
    blackScreen = load_image("ImageFile\\use_img\\character\\view.png")

    load_file(3)

    for i in range(gv.Height//gv.standardPixel):
        for j in range(gv.Width // gv.standardPixel):
            fire[i][j].fire_x = map[i][j].x
            fire[i][j].fire_y = map[i][j].y
            fire[i][j].state = False
            fire[i][j].hp = 20000

    fire[8][17].state = True


def handle_events(frame_time):
    global tl_x, tl_y
    global keyA

    events = get_events()
    for event in events:
        chmp.handle_events(event)
        if event.type == SDL_QUIT:
           Main_Manager.quit()
        elif event.type == SDL_KEYDOWN and event.key == SDLK_ESCAPE:
            Main_Manager.change_state(State_Main)


        if (event.type, event.key) == (SDL_KEYDOWN, SDLK_a):
            keyA = True
        if (event.type, event.key) == (SDL_KEYUP, SDLK_a):
            keyA = False



def update(frame_time):
    buff = map[(int)(chmp.y//gv.standardPixel)][(int)(chmp.x//gv.standardPixel)].state
    chmp.setSt(buff)
    chmp.update(frame_time)
    Collide_wat()

    for i in range(gv.Height//gv.standardPixel):
        for j in range(gv.Width // gv.standardPixel):
            fire[i][j].update(frame_time)
            fire_spread(i, j)



def draw(frame_time):

    for i in range(gv.Height//gv.standardPixel):
        for j in range(gv.Width//gv.standardPixel):
            map[i][j].draw()
            fire[i][j].draw()

    chmp.draw(frame_time)
    blackScreen.draw(chmp.x, chmp.y)





def exit():
    pass





def fire_spread(i, j):

    if fire[i][j].hp < 19550:
        spread_cross(i ,j-1, i, j)
        spread_cross(i ,j+1, i, j)
        spread_cross(i-1, j, i, j)
        spread_cross(i+1, j, i, j)

    if map[i][j].state == gv.oil and fire[i][j].state == True:
        fire[i][j-1].state = True
        fire[i][j+1].state = True
        fire[i-1][j].state = True
        fire[i+1][j].state = True
        fire[i-1][j-1].state = True
        fire[i+1][j+1].state = True
        fire[i-1][j+1].state = True
        fire[i+1][j-1].state = True
        fire[i-2][j-2].state = True
        fire[i+2][j+2].state = True
        fire[i-2][j+2].state = True
        fire[i+2][j-2].state = True



def spread_cross(a, b, q, w):
    if (map[a][b].state != gv.non and map[a][b].state != gv.tree_cut and
                map[a][b].state != gv.stone1 and map[a][b].state != gv.stone2 and map[a][b].state != gv.water):
        #확산 속도가 다름
        if (map[a][b].state == gv.stone2 or map[a][b].state == gv.wood1 or map[a][b].state == gv.wood2):
            if(fire[q][w].hp < 18700):
                fire[a][b].state = True
        elif (map[a][b].state == gv.tree1 or map[a][b].state == gv.tree2):
            fire[a][b].state = True
        else:
            if(fire[q][w].hp < 19200):
                fire[a][b].state = True


def Collide_wat():
    global tl_x, tl_y

    if keyA == True:
        if chmp.dir == gv.Right_dir:
            tl_x = (int)(chmp.x + chmp.wat_x) // gv.standardPixel
            tl_y = (int)(chmp.y) // gv.standardPixel

            if (fire[tl_y][tl_x].state == True or (map[tl_y][tl_x].state in (gv.wood1, gv.wood2, gv.stone1, gv.stone2))):
                chmp.limit = chmp.wat_x
                fire[tl_y][tl_x].hp += damage


        elif chmp.dir == gv.Left_dir:
            tl_x = (int)(chmp.x - chmp.wat_x) // gv.standardPixel
            tl_y = (int)(chmp.y) // gv.standardPixel

            if (fire[tl_y][tl_x].state == True or (
                map[tl_y][tl_x].state in (gv.wood1, gv.wood2, gv.stone1, gv.stone2))):
                chmp.limit = chmp.wat_x
                fire[tl_y][tl_x].hp += damage

        elif chmp.dir == gv.Up_dir:
            tl_x = (int)(chmp.x) // gv.standardPixel
            tl_y = (int)(chmp.y + chmp.wat_y) // gv.standardPixel

            if (fire[tl_y][tl_x].state == True or (map[tl_y][tl_x].state in (gv.wood1, gv.wood2, gv.stone1, gv.stone2))):
                chmp.limit = chmp.wat_y
                fire[tl_y][tl_x].hp += damage

        elif chmp.dir == gv.Down_dir:
            tl_x = (int)(chmp.x) // gv.standardPixel
            tl_y = (int)(chmp.y - chmp.wat_y) // gv.standardPixel

            if (fire[tl_y][tl_x].state == True or (map[tl_y][tl_x].state in (gv.wood1, gv.wood2, gv.stone1, gv.stone2))):
                chmp.limit = chmp.wat_y
                fire[tl_y][tl_x].hp += damage
