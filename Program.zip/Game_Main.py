import platform
import os

if platform.architecture()[0] == '32bit':
    os.environ["PYSDL2-DLL-PATH"] = "./SDL2/x86"
else:
    os.environ["PYSDL2_DLL_PATH"] = "./SDL2/x64"


from pico2d import *
import Main_Manager
import Main_State

import State_Main


open_canvas(Main_State.Width, Main_State.Height)
Main_Manager.main(Main_State)
close_canvas()