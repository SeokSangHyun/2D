import random
from pico2d import *


class Fire:
    fire_img = None
    smoke_img = None

    def __init__(self):
        self.fire_x, self.fire_y = 0, 0
        self.hp = 0
        self.state = False

        self.action_time = 0
        self.frame_fire = random.randint(0, 6)
        self.frame_smoke = self.frame_fire
        if Fire.fire_img == None:
            Fire.fire_img = load_image('ImageFile\\use_img\\fire_state\\fire.png')
        if Fire.smoke_img == None:
            Fire.smoke_img = load_image('ImageFile\\use_img\\fire_state\\pre_fire.png')

    def update(self, frame_time):
        if self.state == True:
            self.action_time += ((1.5*6)*frame_time)
            self.frame_fire = (int)(self.action_time) % 6
            self.frame_smoke = (int)(self.action_time) % 6

            self.hp -= 1

    def draw(self):
        if self.state == True:
            self.smoke_img.clip_draw(self.frame_smoke * 20, 0, 20, 20, self.fire_x, self.fire_y)
            self.fire_img.clip_draw(self.frame_fire * 20, 0, 20, 20, self.fire_x, self.fire_y)

