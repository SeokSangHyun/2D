import random
from pico2d import *

class Smoke:
    smoke_img = None

    def __init__(self):
        self.x, self.y = 100, 100
        self.frame_x = 0
        if Smoke.smoke_img == None:
            Smoke.smoke_img = load_image('ImageFile\\use_img\\fire_state\\pre_fire.png')

    def update(self):
        self.frame_x = (self.frame_x + 1) % 6

    def draw(self):
        self.smoke_img.clip_draw(self.frame_x*20, 0, 20, 20, self.x, self.y)




class Fire:
    fire_img = None
    Smoke_img = None

    def __init__(self):
        self.fire_x, self.fire_y = 0, 0
        state = False

        self.frame_fire = 0
        self.frmae_smoke = 0
        if Fire.fire_img == None:
            Fire.fire_img = load_image('ImageFile\\use_img\\fire_state\\fire.png')
        if Fire.smoke_img == None:
            Fire.smoke_img = load_image('ImageFile\\use_img\\fire_state\\pre_fire.png')

    def update(self):
        if self.state == True:
            self.frame_fire = (self.frame_x + 1) % 6
            self.frame_smoke = random.randint(0, 7)

    def draw(self):
        if self.state == True:
            self.fire_img.clip_draw(self.frame_fire * 20, 0, 20, 20, self.x, self.y)
            self.smoke_imt.clip_draw(self.frame_fire*20, 0, 20, 20, self.x, self.y)

