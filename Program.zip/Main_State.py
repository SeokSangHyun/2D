import Main_Manager
from pico2d import *

import State_Main

Width = 960
Height = 500


menu1 = None
menu2 = None
turn = 0
time_count = 0

def enter():
    global menu1
    global menu2
    global font
    global time_count

    time_count = 0
    font = load_font("ENCR10B.TTF", 100)
    menu1 = load_image("ImageFile\\use_img\\Menu\\menu1.png")
    menu2 = load_image("ImageFile\\use_img\\Menu\\menu2.png")

def exit():
    global menu1
    global menu2

    del(menu1)
    del(menu2)





def handle_events(frame_time):

    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
           Main_Manager.quit()
        elif event.type == SDL_KEYDOWN and event.key == SDLK_ESCAPE:
            Main_Manager.quit()




def update(frame_time):
    global menu1
    global menu2
    global turn
    global time_count

    time_count += 1
    if time_count > 200 and turn == 0:
       turn = 1
       time_count = 0
    elif time_count > 200 and turn == 1:
        turn = 2

    elif turn == 2:
        Main_Manager.change_state(State_Main)





def draw(frame_time):
    global menu1
    global menu2
    global turn
    global font

    if turn == 0:
        font = load_font("ENCR10B.TTF", 150)
        menu1.draw(Width / 2, Height / 2, Width, Height)
        font.draw(50, 300, "Fire Fight", (255, 0, 0))
    elif turn == 1:
        font = load_font("ENCR10B.TTF", 70)
        menu2.draw(Width / 2, Height / 2, Width, Height)
        font.draw(50, 450, "2DGP_2013182023", (250, 250, 250))
        font.draw(50, 50, "Make Vary Hard!!", (150, 0, 180))