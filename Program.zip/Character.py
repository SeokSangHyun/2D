import Main_Manager
import State_BackGround

from globalVari import GV
import State_Main
from pico2d import *


gv = GV()
Range = 120

class character:
    chmp =  None
    water_up = None
    water_down = None
    water_right = None
    water_left = None

    def __init__(self):
        self.x = 100
        self.y = 100
        self.st = 0
        self.speed = 0  #   분속 4m
        self.dir = gv.Right_dir
        self.water_split = 0
        self.frame = 0

        self.width = gv.standardPixel
        self.height = gv.standardPixel

        self.limit = 120
        self.wat_ptx = 20   #
        self.wat_pty = 20   #
        self.wat_x = 20      #   가로 물 줄기 길이
        self.wat_y = 20     #   세로 물 줄기 길이
        self.flag = False
        self.wat_frame = 0

        self.action_time = 0

        if character.chmp == None:
            character.chmp = load_image("ImageFile\\use_img\\character\\chmp.png")
        if character.water_up == None:
            character.water_up = load_image("ImageFile\\use_img\\character\\sprite_up.png")
        if character.water_down == None:
            character.water_down = load_image("ImageFile\\use_img\\character\\sprite_down.png")
        if character.water_right == None:
            character.water_right = load_image("ImageFile\\use_img\\character\\sprite_right.png")
        if character.water_left == None:
            character.water_left = load_image("ImageFile\\use_img\\character\\sprite_left.png")

    def handle_events(self, event):
        if (event.type, event.key) == (SDL_KEYDOWN, SDLK_LEFT):
            self.dir = gv.Left_dir
            self.wat_pty = 20
            self.wat_y = 20
            self.speed = 60
        elif (event.type, event.key) == (SDL_KEYUP, SDLK_LEFT):
            self.speed = 0
        elif(event.type, event.key) == (SDL_KEYDOWN, SDLK_RIGHT):
            self.dir = gv.Right_dir
            self.wat_pty = 20
            self.wat_y = 20
            self.speed = 60
        elif (event.type, event.key) == (SDL_KEYUP, SDLK_RIGHT):
            self.speed = 0
        elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_UP):
            self.dir = gv.Up_dir
            self.wat_ptx = 20
            self.wat_x = 20
            self.speed = 60
        elif (event.type, event.key) == (SDL_KEYUP, SDLK_UP):
            self.speed = 0
        elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_DOWN):
            self.dir = gv.Down_dir
            self.wat_ptx = 20
            self.wat_x = 20
            self.speed = 60
        elif (event.type, event.key) == (SDL_KEYUP, SDLK_DOWN):
            self.speed = 0

        if(event.type, event.key) == (SDL_KEYDOWN, SDLK_a):
            if self.dir in (gv.Right_dir, gv.Left_dir,gv.Up_dir, gv.Down_dir ):
                self.flag = True

                #            elif self.dir in (Up_dir, Down_dir, ):
        elif(event.type, event.key) == (SDL_KEYUP, SDLK_a):
            self.flag = False
            self.limit = 120
            self.wat_x = 20
            self.wat_y = 20



    def update(self, frame_time):
        if self.flag == True:
            self.wat_frame = (self.wat_frame+1)%6
            if (self.dir == gv.Right_dir or self.dir == gv.Left_dir):
                if self.wat_x < self.limit:
                    self.wat_x += 2
            if(self.dir == gv.Up_dir or self.dir == gv.Down_dir):
                if self.wat_y < self.limit:
                    self.wat_y += 2
        self.action_time += ((2 * 1) * frame_time)
        self.frame = (int)(self.action_time)%6


        if self.dir == gv.Left_dir:
            self.x -= (self.speed * frame_time)
            if self.st in (gv.wood1, gv.wood2, gv.water, gv.stone1, gv.stone2):
                self.x +=((self.speed*frame_time)+10)
            self.wat_pty = 20
        elif self.dir == gv.Right_dir:
            self.x += (self.speed * frame_time)
            if self.st in (gv.wood1, gv.wood2, gv.water, gv.stone1, gv.stone2):
                self.x -=((self.speed*frame_time)+10)
            self.wat_pty = 20
        elif self.dir == gv.Up_dir:
            self.y += (self.speed * frame_time)
            if self.st in (gv.wood1, gv.wood2, gv.water, gv.stone1, gv.stone2):
                self.y -=((self.speed*frame_time)+10)
            self.wat_ptx = 20
        elif self.dir == gv.Down_dir:
            self.y -= (self.speed * frame_time)
            if self.st in (gv.wood1, gv.wood2, gv.water, gv.stone1, gv.stone2):
                self.y +=((self.speed*frame_time)+10)
            self.wat_ptx = 20

        print((self.x+self.wat_x)//gv.standardPixel, (self.y + self.wat_y)//gv.standardPixel)


    def get(self):
         return self.x-gv.standardPixel/2, self.y+gv.standardPixel/2, self.x+gv.standardPixel/2, self.y-gv.standardPixel/2


    def draw(self, frame_time):
        if self.flag == True:
            if self.dir == gv.Right_dir:
                self.water_right.clip_draw(self.wat_ptx, self.wat_pty * self.wat_frame,    self.wat_x, self.wat_y,      self.x+self.wat_x/2, self.y )
            elif self.dir == gv.Left_dir:
                self.water_left.clip_draw(self.wat_ptx, self.wat_pty * self.wat_frame,    self.wat_x, self.wat_y,       self.x - self.wat_x / 2, self.y)
            elif self.dir == gv.Up_dir:
                self.water_up.clip_draw(self.wat_ptx * self.wat_frame, self.wat_pty,       self.wat_x, self.wat_y,       self.x, self.y+ self.wat_y /2)
            elif self.dir == gv.Down_dir:
                self.water_down.clip_draw(self.wat_ptx * self.wat_frame, self.wat_pty,     self.wat_x, self.wat_y,       self.x, self.y- self.wat_y /2)

        self.chmp.clip_draw(self.frame*self.width, self.dir*self.width, self.width, self.height, self.x, self.y)



    def exit(self):
        pass


    def setSt(self, st):
        self.st = st
