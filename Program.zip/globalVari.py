import json

class GV:
    def __init__(self):
        self.Width = 960
        self.Height = 500
        self.standardPixel = 20

        self.tree_cut = 1005
        self.non = 1010
        self.oil = 1015

        self.wood1 = 1020
        self.wood2 = 1040
        self.wood3 = 1060
        self.wood4 = 1080

        self.water = 1100

        self.grass1 = 1120
        self.grass2 = 1140
        self.grass3 = 1160

        self.stone1 = 1030
        self.stone2 = 1050
        self.stone3 = 1070

        self.tree1 = 1130
        self.tree2 = 1150

        self.nothing = 5
        self.Right_dir = 3
        self.Left_dir = 2
        self.Up_dir = 1
        self.Down_dir = 0
