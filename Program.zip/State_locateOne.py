import Main_Manager
from Character import character
from State_BackGround import BackGround
from pico2d import *
import State_BackGround
import State_Main
import globalVari


chmp = None
image = None
kk = False
kkk = None
map = None

def enter():
    global image, map, chmp, kkk

    chmp = character()

    State_BackGround.load_file(1)
    kkk = load_image("..\\ImageFile\\use_img\\character\\view.png")



def handle_events(frame_time):

    events = get_events()
    for event in events:
        chmp.handle_events(event)
        if event.type == SDL_QUIT:
           Main_Manager.quit()
        elif event.type == SDL_KEYDOWN and event.key == SDLK_ESCAPE:
            Main_Manager.change_state(State_Main)




def update(frame_time):
    chmp.update(frame_time)

#    for i in range(globalVari.Height // globalVari.standardPixel):
#        for j in range(globalVari.Width // globalVari.standardPixel):
#            if map[i][j].state in (globalVari.stone1, globalVari.stone2, globalVari.stone3, globalVari.tree1, globalVari.tree2, globalVari.water,
#                                   globalVari.wood1, globalVari.wood2,globalVari.wood3, globalVari.wood4):
#                if collide(chmp, map[i][j]):
#                    if chmp.dir == globalVari.Left_dir:
#                        chmp.x += 10
#                    if chmp.dir == globalVari.Right_dir:
#                        chmp.x -= 10
#                    if chmp.dir == globalVari.Up_dir:
#                        chmp.y -= 10
#                    if chmp.dir == globalVari.Down_dir:
#                        chmp.y += 10





def draw(frame_time):
    image.draw(globalVari.Width / 2, globalVari.Height / 2, globalVari.Width, globalVari.Height)
    State_BackGround.draw()
    chmp.draw(frame_time)
    kkk.draw(chmp.x, chmp.y)



def exit():
    chmp.exit()