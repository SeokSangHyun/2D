from pico2d import *
import Main_Manager

from Character import character
import State_BackGround


chmp = None
map = None


def create_world():
    global chmp, map

    chmp = character()
    map = State_BackGround()



def destroy_world():
    global chmp, map

    del(chmp)
    del(map)



def enter():
    open_canvas()
    Main_Manager.reset_time()
    create_world()


def exit():
    destroy_world()
    close_canvas()






def Tile_BetwCol_Charac(tile, chmp):
    left_tile, bottom_tile, right_tile, top_tile = tile.get()
    left_chmp, bottom_chmp, right_chmp, top_chmp = chmp.get()

    if left_tile < left_chmp and right_chmp < right_tile:
        if bottom_tile < bottom_chmp and top_chmp < top_tile:
            return True
    return False




def handle_events(frame_time):
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            Main_Manager.quit()
        else:
            if (event.type, event.key) == (SDL_KEYDOWN, SDLK_ESCAPE):
                Main_Manager.quit()



def update(frame_time):
    chmp.update(frame_time)
    map.update(frame_time)

    for tile in map.map:
        if Tile_BetwCol_Charac(tile, chmp):

            if chmp.dir == chmp.Left_dir:
                chmp.x += (chmp.speed * frame_time)
            elif chmp.dir == chmp.Right_dir:
                chmp.x -= (chmp.speed * frame_time)
            elif chmp.dir == chmp.Up_dir:
                chmp.y -= (chmp.speed * frame_time)
            elif chmp.dir == chmp.Down_dir:
                chmp.y += (chmp.speed * frame_time)



def draw(frame_time):
    chmp.drdaw(frame_time)
    map.draw(frame_time)

