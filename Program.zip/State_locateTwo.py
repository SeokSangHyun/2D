import Main_Manager
from pico2d import *
import State_Main
import globalVari
import State_BackGround


image = None

def enter():
    global image
    global map

    State_BackGround.load_file(2)
    image = load_image("..\\ImageFile\\use_img\Map\\noem.png")



def handle_events(frame_time):

    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
           Main_Manager.quit()
        elif event.type == SDL_KEYDOWN and event.key == SDLK_ESCAPE:
            Main_Manager.change_state(State_Main)





def update(frame_time):
    pass




def draw(frame_time):
    image.draw(globalVari.Width / 2, globalVari.Height / 2, globalVari.Width, globalVari.Height)
    State_BackGround.draw()

def exit():
    pass