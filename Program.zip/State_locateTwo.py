import Main_Manager
from Character import character
from globalVari import GV
from State_BackGround import BackGround
from Fire import Fire
from pico2d import *
import State_Main
import Win
import Lose


gv = GV()

item = [0 for i in range(2)]
itemst = 0
image = None
blackScreen = None
map = None

chmp = None # 불과 캐릭터
fire = None
damage = 30
keyA = False

count = 0 #숫자 카운트
wordx, wordy = gv.Width-80, gv.Height-20
font = None

def load_file(stage):
    f = open("map3(900, 600).txt", 'r')
    for i in range(gv.Height // gv.standardPixel):
        for j in range(gv.Width // gv.standardPixel):
            map[i][j].x = (int)(f.readline())
            map[i][j].y = (int)(f.readline())
            map[i][j].state = (int)(f.readline())
    f.close()



def enter():
    global blackScreen, font
    global map, chmp, fire

    chmp = character()
    fire =[[Fire()for i in range(gv.Width//gv.standardPixel)] for j in range(gv.Height//gv.standardPixel)]
    map = [[BackGround() for i in range(gv.Width//gv.standardPixel)] for j in range(gv.Height//gv.standardPixel)]
    blackScreen = load_image("ImageFile\\use_img\\character\\view.png")
    item[0] = load_image("ImageFile\\use_img\\item\\watersprite.png")
    item[1] = load_image("ImageFile\\use_img\\item\\axe.png")
    font = load_font("ENCR10B.TTF", 50)
    load_file(3)

    for i in range(gv.Height//gv.standardPixel):
        for j in range(gv.Width // gv.standardPixel):
            fire[i][j].fire_x = map[i][j].x
            fire[i][j].fire_y = map[i][j].y
            fire[i][j].state = False
            fire[i][j].hp = 20000

    fire[9][18].state = True


def handle_events(frame_time):
    global tl_x, tl_y
    global keyA, itemst, item

    events = get_events()
    for event in events:
        chmp.handle_events(event)
        if event.type == SDL_QUIT:
           Main_Manager.quit()
        elif event.type == SDL_KEYDOWN and event.key == SDLK_ESCAPE:
            Main_Manager.change_state(State_Main)

        if (event.type, event.key) == (SDL_KEYDOWN, SDLK_s):
            itemst = 1 - itemst

        if (event.type, event.key) == (SDL_KEYDOWN, SDLK_a):
            keyA = True
        if (event.type, event.key) == (SDL_KEYUP, SDLK_a):
            keyA = False



def update(frame_time):
    global count

    count = 0
    buff = map[(int)(chmp.y//gv.standardPixel)][(int)(chmp.x//gv.standardPixel)].state
    chmp.setSt(buff, itemst)
    chmp.update(frame_time)
    Collide_wat()

    for i in range(gv.Height//gv.standardPixel):
        for j in range(gv.Width // gv.standardPixel):
            fire_spread(i, j)
            fire[i][j].update(frame_time)
            if keyA == True and (buff in (gv.tree1, gv.tree2)):
                map[(int)(chmp.y // gv.standardPixel)][(int)(chmp.x // gv.standardPixel)].state = gv.tree_cut
            if fire[i][j].state == True:
                count += 1

    if count >= 50:
        Main_Manager.change_state(Lose)
    elif count == 0:
        Main_Manager.change_state(Win)



def draw(frame_time):

    for i in range(gv.Height//gv.standardPixel):
        for j in range(gv.Width//gv.standardPixel):
            map[i][j].draw()
            fire[i][j].draw()

    chmp.draw(frame_time)
    wordCount()

    if itemst == 0:
        item[0].draw(gv.Width-50, 30, 50, 50)
    elif itemst == 1:
        item[1].draw(gv.Width-50, 30, 50, 50)





def exit():
    pass





def fire_spread(i, j):

    if fire[i][j].hp < 19550:
        spread_cross(i ,j-1, i, j)
        spread_cross(i ,j+1, i, j)
        spread_cross(i-1, j, i, j)
        spread_cross(i+1, j, i, j)

    if map[i][j].state == gv.oil and fire[i][j].state == True:
        fire[i][j-1].state = True
        fire[i][j+1].state = True
        fire[i-1][j].state = True
        fire[i+1][j].state = True
        fire[i-1][j-1].state = True
        fire[i+1][j+1].state = True
        fire[i-1][j+1].state = True
        fire[i+1][j-1].state = True
        fire[i-2][j-2].state = True
        fire[i+2][j+2].state = True
        fire[i-2][j+2].state = True
        fire[i+2][j-2].state = True



def spread_cross(a, b, q, w):
    if (map[a][b].state != gv.non and map[a][b].state != gv.tree_cut and
                map[a][b].state != gv.stone1 and map[a][b].state != gv.stone2 and map[a][b].state != gv.water):
        #확산 속도가 다름
        if (map[a][b].state == gv.stone2 or map[a][b].state == gv.wood1 or map[a][b].state == gv.wood2):
            if(fire[q][w].hp < 18700):
                fire[a][b].state = True
        elif (map[a][b].state == gv.tree1 or map[a][b].state == gv.tree2):
            fire[a][b].state = True
        else:
            if(fire[q][w].hp < 19200):
                fire[a][b].state = True


def Collide_wat():
    global tl_x, tl_y

    if keyA == True:
        if chmp.dir == gv.Right_dir:
            tl_x = (int)(chmp.x + chmp.wat_x-5) // gv.standardPixel
            tl_y = (int)(chmp.y-5) // gv.standardPixel

            if (fire[tl_y][tl_x].state == True or (map[tl_y][tl_x].state in (gv.wood1, gv.wood2, gv.stone1, gv.stone2))):
                chmp.limit = chmp.wat_x
                fire[tl_y][tl_x].hp += damage
            print(tl_x, tl_y)


        elif chmp.dir == gv.Left_dir:
            tl_x = (int)(chmp.x - chmp.wat_x-5) // gv.standardPixel
            tl_y = (int)(chmp.y-5) // gv.standardPixel

            if (fire[tl_y][tl_x].state == True or (
                map[tl_y][tl_x].state in (gv.wood1, gv.wood2, gv.stone1, gv.stone2))):
                chmp.limit = chmp.wat_x
                fire[tl_y][tl_x].hp += damage
            print(tl_x, tl_y)

        elif chmp.dir == gv.Up_dir:
            tl_x = (int)(chmp.x-5) // gv.standardPixel
            tl_y = (int)(chmp.y + chmp.wat_y-5) // gv.standardPixel

            if (fire[tl_y][tl_x].state == True or (
                        map[tl_y][tl_x].state in (gv.wood1, gv.wood2, gv.stone1, gv.stone2))):
                chmp.limit = chmp.wat_y
                fire[tl_y][tl_x].hp += damage
            print(tl_x, tl_y)

        elif chmp.dir == gv.Down_dir:
            tl_x = (int)(chmp.x-5) // gv.standardPixel
            tl_y = (int)(chmp.y - chmp.wat_y-5) // gv.standardPixel

            if (fire[tl_y][tl_x].state == True or (
                        map[tl_y][tl_x].state in (gv.wood1, gv.wood2, gv.stone1, gv.stone2))):
                chmp.limit = chmp.wat_y
                fire[tl_y][tl_x].hp += damage
            print(tl_x, tl_y)


def wordCount():
    hundred = count//100
    ten = (count - hundred*100)//10
    one = (count - hundred*100 - ten*10)

    wordDraw(hundred, wordx, wordy)
    wordDraw(ten, wordx + 25, wordy)
    wordDraw(one, wordx + 50, wordy)


def wordDraw(num, m_x, m_y):

    if num == 0:
        font.draw(m_x, m_y, "0", (100 + count, 0, 0))
    if num == 1:
        font.draw(m_x, m_y, "1", (100 + count, 0, 0))
    if num == 2:
        font.draw(m_x, m_y, "2", (100 + count, 0, 0))
    if num == 3:
        font.draw(m_x, m_y, "3", (100 + count, 0, 0))
    if num == 4:
        font.draw(m_x, m_y, "4", (100 + count, 0, 0))
    if num == 5:
        font.draw(m_x, m_y, "5", (100 + count, 0, 0))
    if num == 6:
        font.draw(m_x, m_y, "6", (100 + count, 0, 0))
    if num == 7:
        font.draw(m_x, m_y, "7", (100 + count, 0, 0))
    if num == 8:
        font.draw(m_x, m_y, "8", (100 + count, 0, 0))
    if num == 9:
        font.draw(m_x, m_y, "9", (100 + count, 0, 0))