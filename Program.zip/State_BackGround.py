from pico2d import *
from globalVari import GV


gv = GV()

class BackGround:
    wood1, wood2, wood3, wood4 = None, None, None, None
    water = None
    grass1, grass2, grass3 = None, None, None
    stone1, stone2, stone3 = None, None, None
    tree1, tree2 = None, None
    non, tree_cut, oil = None, None, None

    def __init__(self):
        self.x, self.y = 0, 0
        self.state = 1000

        if BackGround.wood1 == None:
            BackGround.wood1 = load_image("ImageFile\\use_img\\Map\\wood1.png")
        if BackGround.wood2 == None:
            BackGround.wood2 = load_image('ImageFile\\use_img\\Map\\wood2.png')
        if BackGround.wood3 == None:
            BackGround.wood3 = load_image('ImageFile\\use_img\\Map\\wood3.png')
        if BackGround.wood4 == None:
            BackGround.wood4 = load_image('ImageFile\\use_img\\Map\\wood4.png')

        if BackGround.water == None:
            BackGround.water = load_image('ImageFile\\use_img\\Map\\bg_water.png')

        if BackGround.grass1 == None:
            BackGround.grass1 = load_image('ImageFile\\use_img\\Map\\bg_grass.png')
        if BackGround.grass2 == None:
            BackGround.grass2 = load_image('ImageFile\\use_img\\Map\\bg_grass2.png')
        if BackGround.grass3 == None:
            BackGround.grass3 = load_image('ImageFile\\use_img\\Map\\bg_grass3.png')

        if BackGround.stone1 == None:
            BackGround.stone1 = load_image('ImageFile\\use_img\\Map\\stone.png')
        if BackGround.stone2 == None:
            BackGround.stone2 = load_image('ImageFile\\use_img\\Map\\stone1.png')
        if BackGround.stone3 == None:
            BackGround.stone3 = load_image('ImageFile\\use_img\\Map\\stone2.png')

        if BackGround.tree1 == None:
            BackGround.tree1 = load_image('ImageFile\\use_img\\Map\\bg_tree.png')
        if BackGround.tree2 == None:
            BackGround.tree2 = load_image('ImageFile\\use_img\\Map\\bg_tree2.png')

        if BackGround.non == None:
            BackGround.non = load_image('ImageFile\\use_img\\Map\\non.png')
        if BackGround.tree_cut == None:
            BackGround.tree_cut = load_image('ImageFile\\use_img\\Map\\tree_cut.png')
        if BackGround.oil == None:
            BackGround.oil = load_image('ImageFile\\use_img\\Map\\oil.png')



    def draw(self):
        if self.state == gv.wood1:
            self.wood1.draw(self.x, self.y)
        elif self.state == gv.wood2:
            self.wood2.draw(self.x, self.y)
        elif self.state == gv.wood3:
            self.wood3.draw(self.x, self.y)
        elif self.state == gv.wood4:
            self.wood4.draw(self.x, self.y)

        elif self.state == gv.water:
            self.water.draw(self.x, self.y)

        elif self.state == gv.grass1:
            self.grass1.draw(self.x, self.y)
        elif self.state == gv.grass2:
            self.grass2.draw(self.x, self.y)
        elif self.state == gv.grass3:
            self.grass3.draw(self.x, self.y)

        elif self.state == gv.stone1:
            self.stone1.draw(self.x, self.y)
        elif self.state == gv.stone2:
            self.stone2.draw(self.x, self.y)
        elif self.state == gv.stone3:
            self.stone3.draw(self.x, self.y)

        elif self.state == gv.tree1:
            self.tree1.draw(self.x, self.y)
        elif self.state == gv.tree2:
            self.tree2.draw(self.x, self.y)

        elif self.state == gv.non:
            self.non.draw(self.x, self.y)
        elif self.state == gv.tree_cut:
            self.tree_cut.draw(self.x, self.y)
        elif self.state == gv.oil:
            self.oil.draw(self.x, self.y)

    def get(map):
        return map.x - gv.standardPixel / 2, map.y + gv.standardPixel / 2, map.x + gv.standardPixel / 2, map.y - gv.standardPixel / 2
