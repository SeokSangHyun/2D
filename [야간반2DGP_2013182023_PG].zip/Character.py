import Main_Manager
from pico2d import *
import State_Main
import globalVari

nothing = 4
Right_dir = 3
Left_dir = 2
Up_dir = 1
Down_dir = 0

Range = 120

class character:
    chmp =  None
    water = None

    def __init__(self):
        self.x = 100
        self.y = 100
        self.speed = 0  #   분속 4m
        self.dir = Right_dir
        self.water_split = 0
        self.frame = 0

        self.width = globalVari.standardPixel
        self.height = globalVari.standardPixel

        self.wat_ptx = 60
        self.wat_pty = 20
        self.wat_x = 0#length
        self.wat_y = 20
        self.flag = False
        self.wat_frame = 0


        if character.chmp == None:
            character.chmp = load_image("C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\[야간반2DGP_2013182023_IMG]\\use_img\character\\chmp.png")
        if character.water == None:
            character.water = load_image("C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\[야간반2DGP_2013182023_IMG]\\use_img\character\\sprite.png")



    def handle_events(self, event):
        if (event.type, event.key) == (SDL_KEYDOWN, SDLK_LEFT):
            self.dir = Left_dir
            self.speed = 0.06
        elif (event.type, event.key) == (SDL_KEYUP, SDLK_LEFT):
            self.speed = 0
        elif(event.type, event.key) == (SDL_KEYDOWN, SDLK_RIGHT):
            self.dir = Right_dir
            self.speed = 0.06
        elif (event.type, event.key) == (SDL_KEYUP, SDLK_RIGHT):
            self.speed = 0
        elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_UP):
            self.dir = Up_dir
            self.speed = 0.06
        elif (event.type, event.key) == (SDL_KEYUP, SDLK_UP):
            self.speed = 0
        elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_DOWN):
            self.dir = Down_dir
            self.speed = 0.06
        elif (event.type, event.key) == (SDL_KEYUP, SDLK_DOWN):
            self.speed = 0

        if(event.type, event.key) == (SDL_KEYDOWN, SDLK_a):
            if self.dir in (Right_dir, Left_dir, ):
                self.speed = 0.03
                self.flag = True
                #            elif self.dir in (Up_dir, Down_dir, ):
        elif(event.type, event.key) == (SDL_KEYUP, SDLK_a):
            self.flag = False
            self.wat_x = 0



    def update(self, frame_time):
        if self.flag == True:
            self.wat_frame = (self.wat_frame+1)%6
            if self.wat_x < 120:
                self.wat_x += 5
        self.frame = (self.frame+1)%6

        if self.dir == Left_dir:
            self.x -= (self.speed * frame_time)
        elif self.dir == Right_dir:
            self.x += (self.speed * frame_time)
        elif self.dir == Up_dir:
            self.y += (self.speed * frame_time)
        elif self.dir == Down_dir:
            self.y -= (self.speed * frame_time)

    def get(self):
         return self.x-globalVari.standardPixel/2, self.y+globalVari.standardPixel/2, self.x+globalVari.standardPixel/2, self.y-globalVari.standardPixel/2


    def draw(self, frame_time):
        if self.flag == True:
            if self.dir == Right_dir:
                self.water.clip_draw(self.wat_ptx, self.wat_pty * self.wat_frame, self.wat_x, self.wat_y, self.x+self.wat_x/2, self.y )
            if self.dir == Left_dir:
                self.water.clip_draw(self.wat_ptx, self.wat_pty * self.wat_frame, self.wat_x, self.wat_y,self.x - self.wat_x / 2, self.y)
        self.chmp.clip_draw(self.frame*self.width, self.dir*self.width, self.width, self.height, self.x, self.y)

    def exit(self):

        del(character.water)
        del(character.chmp)