from pico2d import *

import globalVari


class BackGround:
    wood1, wood2, wood3, wood4 = None, None, None, None
    water = None
    grass, grass2, grass3 = None, None, None
    stone1, stone2, stone3 = None, None, None
    tree1, tree2 = None, None

    def __init__(self):
        self.x, self.y = 0, 0
        self.state = 1000
        BackGround.wood1 = load_image(
            "C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\[야간반2DGP_2013182023_IMG]\\use_img\\Map\\wood1.png")
        BackGround.wood2 = load_image(
            'C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\[야간반2DGP_2013182023_IMG]\\use_img\\Map\\wood2.png')
        BackGround.wood3 = load_image(
            'C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\[야간반2DGP_2013182023_IMG]\\use_img\\Map\\wood3.png')
        BackGround.wood4 = load_image(
            'C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\[야간반2DGP_2013182023_IMG]\\use_img\\Map\\wood4.png')
        BackGround.water = load_image(
            'C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\[야간반2DGP_2013182023_IMG]\\use_img\\Map\\bg_water.png')
        BackGround.grass = load_image(
            'C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\[야간반2DGP_2013182023_IMG]\\use_img\\Map\\bg_grass.png')
        BackGround.grass2 = load_image(
            'C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\[야간반2DGP_2013182023_IMG]\\use_img\\Map\\bg_grass2.png')
        BackGround.grass3 = load_image(
            'C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\[야간반2DGP_2013182023_IMG]\\use_img\\Map\\bg_grass3.png')

        BackGround.stone1 = load_image(
            'C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\[야간반2DGP_2013182023_IMG]\\use_img\\Map\\stone.png')
        BackGround.stone2 = load_image(
            'C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\[야간반2DGP_2013182023_IMG]\\use_img\\Map\\stone1.png')
        BackGround.stone3 = load_image(
            'C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\[야간반2DGP_2013182023_IMG]\\use_img\\Map\\stone2.png')
        BackGround.tree1 = load_image(
            'C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\[야간반2DGP_2013182023_IMG]\\use_img\\Map\\bg_tree.png')
        BackGround.tree2 = load_image(
            'C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\[야간반2DGP_2013182023_IMG]\\use_img\\Map\\bg_tree2.png')

map = None

def load_file(stage):
    global map
    map = [[BackGround() for i in range(globalVari.Width//globalVari.standardPixel)] for i in range(globalVari.Height//globalVari.standardPixel)]


    if stage == 1:
        f = open("map1(900, 600).txt", 'r')
        for i in range(globalVari.Height // globalVari.standardPixel):
            for j in range(globalVari.Width // globalVari.standardPixel):
                map[i][j].x = (int)(f.readline())
                map[i][j].y = (int)(f.readline())
                map[i][j].state = (int)(f.readline())
        f.close()

    if stage == 2:
        f = open("map2(900, 600).txt", 'r')
        for i in range(globalVari.Height // globalVari.standardPixel):
            for j in range(globalVari.Width // globalVari.standardPixel):
                map[i][j].x = (int)(f.readline())
                map[i][j].y = (int)(f.readline())
                map[i][j].state = (int)(f.readline())
        f.close()

    if stage == 3:
        f = open("map3(900, 600).txt", 'r')
        for i in range(globalVari.Height // globalVari.standardPixel):
            for j in range(globalVari.Width // globalVari.standardPixel):
                map[i][j].x = (int)(f.readline())
                map[i][j].y = (int)(f.readline())
                map[i][j].state = (int)(f.readline())
        f.close()
    return map

def get( map):
    return map.x-globalVari.standardPixel/2, map.y+globalVari.standardPixel/2, map.x+globalVari.standardPixel/2, map.y-globalVari.standardPixel/2

def update():
    pass


def draw():
    global map

    for i in range(globalVari.Height // globalVari.standardPixel):
        for j in range(globalVari.Width // globalVari.standardPixel):
            if map[i][j].state == globalVari.wood1:
                map[i][j].wood1.draw(map[i][j].x, map[i][j].y)
            elif map[i][j].state == globalVari.wood2:
                map[i][j].wood2.draw(map[i][j].x, map[i][j].y)
            elif map[i][j].state == globalVari.wood3:
                map[i][j].wood3.draw(map[i][j].x, map[i][j].y)
            elif map[i][j].state == globalVari.wood4:
                map[i][j].wood4.draw(map[i][j].x, map[i][j].y)
            elif map[i][j].state == globalVari.water:
                map[i][j].water.draw(map[i][j].x, map[i][j].y)
            elif map[i][j].state == globalVari.grass1:
                map[i][j].grass.draw(map[i][j].x, map[i][j].y)
            elif map[i][j].state == globalVari.grass2:
                map[i][j].grass2.draw(map[i][j].x, map[i][j].y)
            elif map[i][j].state == globalVari.grass3:
                map[i][j].grass3.draw(map[i][j].x, map[i][j].y)

            elif map[i][j].state == globalVari.stone1:
                map[i][j].stone1.draw(map[i][j].x, map[i][j].y)
            elif map[i][j].state == globalVari.stone2:
                map[i][j].stone2.draw(map[i][j].x, map[i][j].y)
            elif map[i][j].state == globalVari.stone3:
                map[i][j].stone3.draw(map[i][j].x, map[i][j].y)
            elif map[i][j].state == globalVari.tree1:
                map[i][j].tree1.draw(map[i][j].x, map[i][j].y)
            elif map[i][j].state == globalVari.tree2:
                map[i][j].tree2.draw(map[i][j].x, map[i][j].y)
