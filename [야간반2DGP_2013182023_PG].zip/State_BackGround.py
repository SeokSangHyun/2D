from pico2d import *

import globalVari



class BackGround:
    wood1, wood2, wood3, wood4 = None, None, None, None
    water = None
    grass, grass2, grass3 = None, None, None

    def __init__(self):
        self.x, self.y = 0, 0
        self.state = 1000
        BackGround.wood1 = load_image(
            "C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\[야간반2DGP_2013182023_IMG]\\use_img\\Map\\wood1.png")
        BackGround.wood2 = load_image(
            'C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\[야간반2DGP_2013182023_IMG]\\use_img\\Map\\wood2.png')
        BackGround.wood3 = load_image(
            'C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\[야간반2DGP_2013182023_IMG]\\use_img\\Map\\wood3.png')
        BackGround.wood4 = load_image(
            'C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\[야간반2DGP_2013182023_IMG]\\use_img\\Map\\wood4.png')
        BackGround.water = load_image(
            'C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\[야간반2DGP_2013182023_IMG]\\use_img\\Map\\bg_water.png')
        BackGround.grass = load_image(
            'C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\[야간반2DGP_2013182023_IMG]\\use_img\\Map\\bg_grass.png')
        BackGround.grass2 = load_image(
            'C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\[야간반2DGP_2013182023_IMG]\\use_img\\Map\\bg_grass2.png')
        BackGround.grass3 = load_image(
            'C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\[야간반2DGP_2013182023_IMG]\\use_img\\Map\\bg_grass3.png')

map = None

def load_file( stage):
    global map

    map = [[BackGround() for i in range(globalVari.Width // globalVari.standardPixel)] for j in range(globalVari.Height // globalVari.standardPixel)]

    if stage == 1:
        f = open("map1(900, 600).txt", 'r')
        for i in range(globalVari.Height// globalVari.standardPixel):
            for j in range(globalVari.Width// globalVari.standardPixel):
                map[i][j].x = (int)(f.readline())
                map[i][j].y = (int)(f.readline())
                map[i][j].state = (int)(f.readline())
        f.close()

    if stage == 2:
        f = open("map2(900, 600).txt", 'r')
        for i in range(globalVari.Height// globalVari.standardPixel):
            for j in range(globalVari.Width// globalVari.standardPixel):
                map[i][j].x = (int)(f.readline())
                map[i][j].y = (int)(f.readline())
                map[i][j].state = (int)(f.readline())
        f.close()

    if stage == 3:
        f = open("map3(900, 600).txt", 'r')
        for i in range(globalVari.Height// globalVari.standardPixel):
            for j in range(globalVari.Width// globalVari.standardPixel):
                map[i][j].x = (int)(f.readline())
                map[i][j].y = (int)(f.readline())
                map[i][j].state = (int)(f.readline())
        f.close()


def update():
    pass


def draw():
    global map

    for i in range(globalVari.Height // globalVari.standardPixel):
        for j in range(globalVari.Width // globalVari.standardPixel):
            if map[i][j].state == 1020:
                map[i][j].wood1.draw(map[i][j].x, map[i][j].y)
            elif map[i][j].state == 1040:
                map[i][j].wood2.draw(map[i][j].x, map[i][j].y)
            elif map[i][j].state == 1060:
                map[i][j].wood3.draw(map[i][j].x, map[i][j].y)
            elif map[i][j].state == 1080:
                map[i][j].wood4.draw(map[i][j].x, map[i][j].y)
            elif map[i][j].state == 1100:
                map[i][j].water.draw(map[i][j].x, map[i][j].y)
            elif map[i][j].state == 1120:
                map[i][j].grass.draw(map[i][j].x, map[i][j].y)
            elif map[i][j].state == 1140:
                map[i][j].grass2.draw(map[i][j].x, map[i][j].y)
            elif map[i][j].state == 1160:
                map[i][j].grass3.draw(map[i][j].x, map[i][j].y)
