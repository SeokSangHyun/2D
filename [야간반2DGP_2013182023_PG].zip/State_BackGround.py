from pico2d import *

class BackGround:
    wood1, wood2, wood3, wood4 = None, None, None, None
    water = None
    grass, grass2, grass3 = None, None, None

    def __init__(self):
        self.x, self.y = 0, 0
        self.state = 1000
        if Tile.wood1 == None and self.state == 1020:
            Tile.wood1 = load_image('C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\img\\use_img\\Map\\wood1.png')
        if Tile.wood2 == None and self.state == 1040:
            Tile.wood2 = load_image('C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\img\\use_img\\Map\\wood2.png')
        if Tile.wood3 == None and self.state == 1060:
            Tile.wood3 = load_image('C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\img\\use_img\\Map\\wood3.png')
        if Tile.wood4 == None and self.state == 1080:
            Tile.wood4 = load_image('C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\img\\use_img\\Map\\wood4.png')
        if Tile.water == None and self.state == 1100:
            Tile.water = load_image('C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\img\\use_img\\Map\\bg_water.png')
        if Tile.grass == None and self.state == 1120:
            Tile.grass = load_image('C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\img\\use_img\\Map\\bg_grass.png')
        if Tile.grass2 == None and self.state == 1140:
            Tile.grass2 = load_image('C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\img\\use_img\\Map\\bg_grass2.png')
        if Tile.grass3 == None and self.state == 1160:
            Tile.grass3 = load_image('C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\img\\use_img\\Map\\bg_grass3.png')


    def load_file(self):
     #   for i range


    def update(self):
        pass


    def draw(self):
        if self.state == 1020:
            self.wood1.draw(self.x, self.y)
        elif self.state == 1040:
            self.wood2.draw(self.x, self.y)
        elif self.state == 1060:
            self.wood3.draw(self.x, self.y)
        elif self.state == 1080:
            self.wood4.draw(self.x, self.y)
        elif self.state == 1100:
            self.water.draw(self.x, self.y)
        elif self.state == 1120:
            self.grass.draw(self.x, self.y)
        elif self.state == 1140:
            self.grass2.draw(self.x, self.y)
        elif self.state == 1160:
            self.grass3.draw(self.x, self.y)