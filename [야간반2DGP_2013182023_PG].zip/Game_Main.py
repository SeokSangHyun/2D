from pico2d import *
import Main_Manager
import Main_State

import State_Main


open_canvas(Main_State.Width, Main_State.Height)
Main_Manager.main(Main_State)
close_canvas()