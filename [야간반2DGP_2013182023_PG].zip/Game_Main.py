from pico2d import *
import Main_Manager
import Main_State


open_canvas()
Main_Manager.main(Main_State)
close_canvas()