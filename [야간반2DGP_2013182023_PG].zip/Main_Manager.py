import json
from pico2d import *
import Main_State

class GameState:
    def __init__(self, state):
        self.logo1 = state.logo1
        self.logo2 = state.logo2
        self.enterMain = state.enterMain
        self.mapHouse = state.mapHouse



def Draw(Main_State):
    global menu1
    global menu2
    global time

    time = get_frame_time()
    if time < 5:
        menu1.draw(Main_State.Width / 2, Main_State.Height / 2, Main_State.Width, Main_State.Height)
    elif time > 5:
        menu2.draw(Main_State.Width / 2, Main_State.Height / 2, Main_State.Width, Main_State.Height)

def Update():
    pass



def handle_events():
    global Menu

    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            Menu = False
        elif event.type == SDL_KEYDOWN and event.key == SDLK_ESCAPE:
            Menu = False



def get_frame_time():
    global current_time

    frame_time = get_time() - current_time

    return frame_time


#지금 출력하는 이미지를 지우고
#출력하려는 이미지로 바꾸어 출력한다.
def Change_state(state):
    global stack

#    pop_state()
    stack.append(state)
    state.create()


#
Menu = True
#

def main(Main_State):
    global Menu
    global frame_time
    global current_time
    global stack
    global menu1, menu2

    menu1 = load_image("C:\\Users\\punch\Desktop\\File\\2D\here\\flod\\Fire_Fight\\[야간반2DGP_2013182023_IMG]\\use_img\\Menu\\menu1.png")
    menu2 = load_image("C:\\Users\\punch\Desktop\\File\\2D\here\\flod\\Fire_Fight\\[야간반2DGP_2013182023_IMG]\\use_img\\Menu\\menu2.png")

    current_time = get_time()

    while Menu:
        clear_canvas()
        handle_events()

        Update()

        Draw(Main_State)
        update_canvas()