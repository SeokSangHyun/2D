import json
import time
import random
from pico2d import *
import Main_State








class GameState:
    def __init__(self, state):
        self.logo1 = state.logo1
        self.logo2 = state.logo2
        self.enterMain = state.enterMain
        self.mapHouse = state.mapHouse





def quit():
    global Menu
    Menu = False


def handle_events():
    global Menu

    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            Menu = False
        elif event.type == SDL_KEYDOWN and event.key == SDLK_ESCAPE:
            Menu = False



def get_frame_time():
    global current_time

    frame_time = get_time() - current_time

    return frame_time







#


def main(Main_State):
    global Menu
    global frame_time
    global current_time
    global stack

    Menu = True
    stack = [Main_State]
    Main_State.enter()


    current_time = get_time()

    while Menu:
        clear_canvas()

        frame_time = time.clock() - current_time

        stack[-1].handle_events(frame_time)
        stack[-1].update(frame_time)
        stack[-1].draw(frame_time)
        update_canvas()












#stack --> 현재 저장 출력할 부분에
#추가, 삭제, 화면(일시적) 전환을 수행한다


#삭제
#stack의 크기가 하나라도 있으면 모두 비운다.
def pop_state():
    global stack

    if len(stack) > 0:
        stack[-1].exit()
        stack.pop()

#화면을 완전히 전환
#1 . stack에 정보를 비운다.
#2 . stack의 가장 마지막에 state정보를 넣는다.
#3 . state 정보를 초기화 한다.
def change_state(state):
    global stack

    pop_state()
    stack.append(state)
    state.enter()



#화면 일시정지

###