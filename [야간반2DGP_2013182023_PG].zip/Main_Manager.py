import json
from pico2d import *

class GameState:
    def __init__(self, state):
        self.stack = None
        pass



def Draw():
    stack(-1).image_draw(400, 500)
    pass



def Update():
    pass



def handle_events():
    global Menu

    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            Menu = False
        elif event.type == SDL_KEYDOWN and event.key == SDLK_ESCAPE:
            Menu = False



def get_frame_time():
    global current_time

    frame_time = get_time() - current_time
    current_time += frame_time

    return frame_time



#
Menu = True
#

def main(Main_State):
    global Menu
    global frame_time
    global current_time
    global stack

    current_time = get_time()

    while Menu:
        clear_canvas()

        frame_time = get_frame_time()
        handle_events()

        Update()

        Draw()


    update_canvas()