
class GameState:
    def __init__(self, state):
        self.enter =






#
Menu = None

#

def main(Main_State):
    global Menu

    while Menu:
        if Main_State ==


