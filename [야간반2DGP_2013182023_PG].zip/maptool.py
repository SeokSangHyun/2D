from pico2d import *
import random
import math


class Character:
    def __init__(self):
        self.x, self.y = None, None
        self.switch = False
        self.frame = 0
        self.image = load_image('C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\[야간반2DGP_2013182023_IMG]\\use_img\\character\\char_right.png')
    def load_image(self,x,y):
        self.x, self.y = x , y

    def Right_dir(self):
        pass

    def Left_dir(self):
        pass

    def Up_dir(self):
        pass

    def Down_dir(self):
        pass

    def update(self):
        self.frame = (self.frame + 1) %6

    def draw(self):
        self.image.clip_draw(self.frame * 20, 0, 20, 20,self.x, self.y)



class Fire:
    image =  None
    def __init__(self):
        self.x, self.y = 0, 0
        self.frame= 0
        self.hp = 2500
        self.spread = False
        self.state = False
        if Fire.image == None:
           Fire.image = load_image('C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\[야간반2DGP_2013182023_IMG]\\use_img\\fire_state\\fire.png')


    def collide(self):
        global fire
        if self.spread == True:
            fire[(self.y+20)//20][(self.x)//20].state = True
            fire[(self.y-20)//20][(self.x)//20].state = True
            fire[(self.y)//20][(self.x+20)//20].state = True
            fire[(self.y)//20][(self.x-20)//20].state = True


    def update(self):
        if self.state == True:
            self.frame = (self.frame + 1) % 6
            if self.hp >= 0:
                self.hp = self.hp - 1
            if self.hp == 2450:
                self.spread = True
                self.collide()



    def draw(self):
        if self.state == True:
            self.image.clip_draw(self.frame * 20, 0, 20, 20, self.x, self.y)




class Tile:
    wood1 = None
    wood2 = None
    wood3 = None
    wood4 = None
    water = None
    grass = None
    grass2 =None
    grass3 =None
    bg_tree = None
    bg_tree2 = None
    stone = None
    stone1 = None
    stone2 = None

    def __init__(self):
        self.x, self.y = 0, 0
        self.state = 1000
        if Tile.wood1 == None:
            Tile.wood1 = load_image('C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\[야간반2DGP_2013182023_IMG]\\use_img\\Map\\wood1.png')
        if Tile.stone == None:
            Tile.stone = load_image('C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\[야간반2DGP_2013182023_IMG]\\use_img\\Map\\stone.png')
        if Tile.wood2 == None:
            Tile.wood2 = load_image('C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\[야간반2DGP_2013182023_IMG]\\use_img\\Map\\wood2.png')
        if Tile.stone1 == None:
            Tile.stone1 = load_image('C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\[야간반2DGP_2013182023_IMG]\\use_img\\Map\\stone1.png')
        if Tile.wood3 == None:
            Tile.wood3 = load_image('C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\[야간반2DGP_2013182023_IMG]\\use_img\\Map\\wood3.png')
        if Tile.stone2 == None:
            Tile.stone2 = load_image('C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\[야간반2DGP_2013182023_IMG]\\use_img\\Map\\stone2.png')
        if Tile.wood4 == None:
            Tile.wood4 = load_image('C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\[야간반2DGP_2013182023_IMG]\\use_img\\Map\\wood4.png')
        if Tile.water == None:
            Tile.water = load_image('C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\[야간반2DGP_2013182023_IMG]\\use_img\\Map\\bg_water.png')
        if Tile.grass == None:
            Tile.grass = load_image('C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\[야간반2DGP_2013182023_IMG]\\use_img\\Map\\bg_grass.png')
        if Tile.bg_tree == None:
            Tile.bg_tree = load_image('C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\[야간반2DGP_2013182023_IMG]\\use_img\\Map\\bg_tree.png')
        if Tile.grass2 == None:
            Tile.grass2 = load_image('C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\[야간반2DGP_2013182023_IMG]\\use_img\\Map\\bg_grass2.png')
        if Tile.bg_tree2 == None:
            Tile.bg_tree2 = load_image('C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\[야간반2DGP_2013182023_IMG]\\use_img\\Map\\bg_tree2.png')
        if Tile.grass3 == None:
            Tile.grass3 = load_image('C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\[야간반2DGP_2013182023_IMG]\\use_img\\Map\\bg_grass3.png')



    def draw(self):
        if self.state == 1020:
            self.wood1.draw(self.x, self.y)
        elif self.state == 1030:
            self.stone.draw(self.x, self.y)
        elif self.state == 1040:
            self.wood2.draw(self.x, self.y)
        elif self.state == 1050:
            self.stone1.draw(self.x, self.y)
        elif self.state == 1060:
            self.wood3.draw(self.x, self.y)
        elif self.state == 1070:
            self.stone2.draw(self.x, self.y)
        elif self.state == 1080:
            self.wood4.draw(self.x, self.y)
        elif self.state == 1100:
            self.water.draw(self.x, self.y)
        elif self.state == 1120:
            self.grass.draw(self.x, self.y)
        elif self.state == 1130:
            self.bg_tree.draw(self.x, self.y)
        elif self.state == 1140:
            self.grass2.draw(self.x, self.y)
        elif self.state == 1150:
            self.bg_tree2.draw(self.x, self.y)
        elif self.state == 1160:
            self.grass3.draw(self.x, self.y)



def mou_events():
    global level
    global fire
    global chmp
    global Menu
    global bg
    global x, y
    global file

    events = get_events()
    for event in events:
        if event.type == SDL_MOUSEMOTION:
            mouX, mouY = event.x, Size[1] - event.y
            ##

        if event.type == SDL_QUIT:
            Menu = False
        elif event.type == SDL_KEYDOWN and event.key == SDLK_ESCAPE:
            Menu = False
        elif event.type == SDL_KEYDOWN and event.key == SDLK_LEFT:
            x = x - 20
            if chmp.switch == True:
                chmp.x  =  x
        elif event.type == SDL_KEYDOWN and event.key == SDLK_RIGHT:
            x = x + 20
            if chmp.switch == True:
                chmp.x = x
        elif event.type == SDL_KEYDOWN and event.key == SDLK_UP:
            y = y + 20
            if chmp.switch == True:
                chmp.y = y
        elif event.type == SDL_KEYDOWN and event.key == SDLK_DOWN:
            y = y - 20
            if chmp.switch == True:
                chmp.y = y

        elif event.type == SDL_KEYDOWN and event.key == SDLK_1:
            level = 1020
        elif event.type == SDL_KEYDOWN and event.key == SDLK_2:
            level = 1040
        elif event.type == SDL_KEYDOWN and event.key == SDLK_3:
            level = 1060
        elif event.type == SDL_KEYDOWN and event.key == SDLK_4:
            level = 1080
        elif event.type == SDL_KEYDOWN and event.key == SDLK_5:
            level = 1100
        elif event.type == SDL_KEYDOWN and event.key == SDLK_6:
            level = 1120
        elif event.type == SDL_KEYDOWN and event.key == SDLK_7:
            level = 1140
        elif event.type == SDL_KEYDOWN and event.key == SDLK_8:
            level = 1160

        elif event.type == SDL_KEYDOWN and event.key == SDLK_9:
            level = 1030
        elif event.type == SDL_KEYDOWN and event.key == SDLK_m:
            level = 1050
        elif event.type == SDL_KEYDOWN and event.key == SDLK_n:
            level = 1070
        elif event.type == SDL_KEYDOWN and event.key == SDLK_b:
            level = 1130
        elif event.type == SDL_KEYDOWN and event.key == SDLK_v:
            level = 1150


        elif event.type == SDL_KEYDOWN and event.key == SDLK_SPACE:
            bg[(int)(y / 20)][(int)(x / 20)].state = level


        elif event.type == SDL_KEYDOWN and event.key == SDLK_r:
            file = open("map4(900, 600).txt", "w")
            for i in range((int)(Size[1] / 20)):
                for j in range((int)(Size[0] / 20)):
                    data = [bg[i][j].x, bg[i][j].y, bg[i][j].state]
                    file.write('%d\n%d\n%d\n'% (data[0], data[1], data[2]))
            file.close()


        elif event.type == SDL_KEYDOWN and event.key == SDLK_e:
            file = open("map4(900, 600).txt", "r")
            for i in range((int)(Size[1] / 20)):
                for j in range((int)(Size[0] / 20)):
                    bg[i][j].x = (int)(file.readline())
                    bg[i][j].y = (int)(file.readline())
                    bg[i][j].state =(int)(file.readline())
            file.close()


        elif event.type == SDL_KEYDOWN and event.key == SDLK_p:
            if chmp.switch == False:
                chmp.load_image(x, y)
                chmp.switch = True
            elif chmp.switch ==True:
                chmp.switch = False


        elif event.type == SDL_KEYDOWN and event.key == SDLK_f:
            fire[(y)//20][(x)//20].state = True















Size = [960, 500]
Menu = True
i,j = 0, 0
level = 1000
x,y = 10, 10

open_canvas(Size[0], Size[1])
chmp = Character()
bg = [[Tile() for one in range(Size[0]//20)] for two in range(Size[1]//20)]
fire = [[Fire() for one in range(Size[0]//20)] for two in range(Size[1]//20)]
location = load_image('C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\[야간반2DGP_2013182023_IMG]\\use_img\\Map\\square.png')
\
for i in range((int)(Size[1] / 20)):
    for j in range((int)(Size[0] / 20)):
        bg[i][j].x, bg[i][j].y = j*20+10, i*20+10
        fire[i][j].x, fire[i][j].y = j*20+10, i*20+10
        gra = random.randint(0,2)
        if gra == 0:
            bg[i][j].state = 1120
        elif gra == 1:
            bg[i][j].state = 1140
        elif gra == 2:
            bg[i][j].state = 1160


while Menu:
    mou_events()
    clear_canvas()


    chmp.update()
    for i in range(Size[1] // 20):
        for j in range(Size[0] // 20):
            fire[i][j].update()
            bg[i][j].draw()
            fire[i][j].draw()


    if chmp.switch == False:
        location.draw(x, y)
    elif chmp.switch == True:
        chmp.draw()
    update_canvas()
    delay(0.05)

close_canvas()

