import Main_Manager
from pico2d import *



image = None

def enter():
    global image
    image = load_image("")




def exit():
    pass






def handle_events(frame_time):

    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
           Main_Manager.quit()
        elif event.type == SDL_KEYDOWN and event.key == SDLK_ESCAPE:
            Main_Manager.quit()



def update(frame_time):
    pass




def draw(frame_time):
    pass