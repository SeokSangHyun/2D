import Main_Manager
from pico2d import *

import State_locateOne
import State_locateTwo
import State_locateThree

Width = 960
Height = 500

image = None
mouse = None
mouse1 = None
click = False

mousePt  = [0 for i in range(2)]

def enter():
    global image
    global mouse,mouse1, click

    image = load_image("C:\\Users\\punch\\Desktop\\File\\2D\here\\flod\Fire_Fight\\[야간반2DGP_2013182023_IMG]\\use_img\\Menu\\main.png")
    mouse = load_image("C:\\Users\\punch\\Desktop\\File\\2D\here\\flod\Fire_Fight\\[야간반2DGP_2013182023_IMG]\\use_img\\Menu\\img_main_click.png")
    mouse1 = load_image("C:\\Users\\punch\\Desktop\\File\\2D\here\\flod\Fire_Fight\\[야간반2DGP_2013182023_IMG]\\use_img\\Menu\\img_main_click_down.png")


def exit():

    pass






def handle_events(frame_time):
    global mousePt, click

    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
           Main_Manager.quit()
        elif event.type == SDL_KEYDOWN and event.key == SDLK_ESCAPE:
            Main_Manager.quit()
        elif event.type == SDL_KEYDOWN and event.key == SDLK_SPACE:
            Main_Manager.change_state(State_locateOne)

        if event.type == SDL_MOUSEMOTION:
            mousePt[0], mousePt[1] = event.x, Height - event.y
        if event.type == SDL_MOUSEBUTTONDOWN and event.button == SDL_BUTTON_LEFT:
            click = True
            if 220 < mousePt[0] and mousePt[0] < 370:
                if 200 < mousePt[1] and mousePt[1] < 230:
                    Main_Manager.change_state(State_locateOne)
            if 500 < mousePt[0] and mousePt[0] < 650:
                if 330 < mousePt[1] and mousePt[1] < 360:
                    Main_Manager.change_state(State_locateTwo)
            if 580 < mousePt[0] and mousePt[0] < 730:
                if 120 < mousePt[1] and mousePt[1] < 140:
                    Main_Manager.change_state(State_locateThree)

        elif event.type == SDL_MOUSEBUTTONUP and event.button == SDL_BUTTON_LEFT:
            click = False



def update(frame_time):
    pass




def draw(frame_time):
    global image
    global mouse, mouse1
    global click

    image.draw(Width / 2, Height / 2, Width, Height)
    if click == True:
        mouse1.draw(mousePt[0], mousePt[1])
    elif click == False:
        mouse.draw(mousePt[0], mousePt[1])