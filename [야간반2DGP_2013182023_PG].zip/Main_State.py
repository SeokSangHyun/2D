import Main_Manager
from pico2d import *

Width = 960
Height = 500


class Game_state:
    menu1 = None
    menu2 = None

    def __init__(self):
        self.time = 0
        if Game_state.menu1 == None:
            self.menu1 = load_image("C:\\Users\\punch\Desktop\\File\\2D\here\\flod\\Fire_Fight\\[야간반2DGP_2013182023_IMG]\\use_img\\Menu\\menu1.png")



    def Create(self, stack):
        stack[-1].append(self.menu1)



    def Enter(self):
        if Game_state.menu2 == None:
            self.menu2 = load_image("C:\\Users\\punch\Desktop\\File\\2D\here\\flod\\Fire_Fight\\[야간반2DGP_2013182023_IMG]\\use_img\\Menu\\menu2.png")


    def Update(self):
        # 5초
        if self.time == 5:
            self.Enter()

    def Draw(self):
        pass


