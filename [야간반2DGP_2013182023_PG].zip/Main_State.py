from pico2d import *

class Game_state:

    def __init__(self):

        pass



def Create():
    pass



def Update():
    pass



def Draw():
    pass


