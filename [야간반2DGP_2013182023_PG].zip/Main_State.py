import Main_Manager
from pico2d import *

import State_Main

Width = 960
Height = 500


menu1 = None
menu2 = None
turn = 0

def enter():
    global menu1
    global menu2

    menu1 = load_image("C:\\Users\\punch\Desktop\\File\\2D\here\\flod\\Fire_Fight\\[야간반2DGP_2013182023_IMG]\\use_img\\Menu\\menu1.png")
    menu2 = load_image("C:\\Users\\punch\Desktop\\File\\2D\here\\flod\\Fire_Fight\\[야간반2DGP_2013182023_IMG]\\use_img\\Menu\\menu2.png")

def exit():
    global menu1
    global menu2

    del(menu1)
    del(menu2)





def handle_events(frame_time):

    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
           Main_Manager.quit()
        elif event.type == SDL_KEYDOWN and event.key == SDLK_ESCAPE:
            Main_Manager.quit()




def update(frame_time):
    global menu1
    global menu2
    global turn

    if frame_time <= 4:
       turn = 0
    elif frame_time > 5:
        turn = 1

    if frame_time >= 8:
        Main_Manager.change_state(State_Main)





def draw(frame_time):
    global menu1
    global menu2
    global turn


    if turn == 0:
        menu1.draw(Width / 2, Height / 2, Width, Height)
    elif turn == 1:
        menu2.draw(Width / 2, Height / 2, Width, Height)