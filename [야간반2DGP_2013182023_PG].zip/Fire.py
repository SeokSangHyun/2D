from pico2d import *


class Smoke:
    smoke_img = None

    def __init__(self):
        self.x, self.y = 100, 100
        self.frame_x = 0
        if Smoke.smoke_img == None:
            Smoke.smoke_img = load_image('C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\img\\use_img\\fire_state\\pre_fire.png')

    def update(self):
        self.frame_x = (self.frame_x + 1) % 6

    def draw(self):
        self.smoke_img.clip_draw(self.frame_x*20, 0, 20, 20, self.x, self.y)




class Fire:
    fire_img = None
    def __init__(self):
        self.x, self.y = 0, 0
        state = False
        self.frame_x = 0
        if Fire.fire_img == None:
            Fire.fire_img = load_image('C:\\Users\\punch\\Desktop\\File\\2D\\here\\flod\\Fire_Fight\\img\\use_img\\fire_state\\fire.png')

    def update(self):
        if state == True:
            self.frame_x = (self.frame_x + 1) % 6

    def draw(self):
        if state == True:
            self.fire_img.clip_draw(self.frame_x * 20, 0, 20, 20, self.x, self.y)


def manager():
    global smoke
    global fire
    global timer

#
    timer[1] = timer[1] + 1
#

    if timer[0] == 0 and timer[1] == 30:
        timer[1] = 0
        timer[0] = timer[0] + 1

    if timer[0] == 1 and timer[1] == 800:
        timer[1] = 2
        timer[0] = timer[0]




def handle_event():
    global Menu

    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            Menu = False
        elif event.type == SDL_KEYDOWN and event.key == SDLK_ESCAPE:
            Menu = False



Size = [900,600]
Menu = True
frame = 0

open_canvas(Size[0], Size[1])
timer = [0, 0]
smoke = Smoke()
fire = Fire()

while Menu:
    handle_event()
    clear_canvas()


    manager()
    if timer[0] == 0:
        smoke.update()
        smoke.draw()
    elif timer[0] == 1:
        fire.update()
        fire.draw()

    update_canvas()

    delay(0.05)

close_canvas()