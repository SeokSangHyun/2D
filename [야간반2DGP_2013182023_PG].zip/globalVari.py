

Width = 960
Height = 500
standardPixel= 20

wood1 = 1020
wood2 = 1040
wood3 = 1060
wood4 = 1080

water = 1100

grass1 = 1120
grass2 = 1140
grass3 = 1160

stone1 = 1030
stone2 = 1050
stone3 = 1070

tree1 = 1130
tree2 = 1150

nothing = 4
Right_dir = 3
Left_dir = 2
Up_dir = 1
Down_dir = 0