

Width = 960
Height = 500
standardPixel= 20